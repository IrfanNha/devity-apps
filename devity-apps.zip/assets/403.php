<?php $pages = '403 Forbidden' ?>
<?php require '../config/Config.php'; ?>
<?php include '../components/templates/header.php'; ?>



<div class="container" style="height:100vh; display: flex; justify-content: center; align-items: center;">
  <div class="text-center">
    <h2>403 Forbidden</h2>
    <p>halaman tidak dapat diakses</p>
  </div>
</div>





<?php include '../components/templates/footer.php'; ?>