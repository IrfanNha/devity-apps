<?php $currentPages = '404 NOT FOUND' ?>
<?php require 'config/Config.php'; ?>
<?php include 'components/templates/header.php'; ?>





<div class="container" style="height:100vh; display: flex; justify-content: center; align-items: center;">
  <div class="text-center">
    <h2>404 Not Found</h2>
    <p>halaman tidak ditemukan</p>
  </div>
</div>







<?php include 'components/templates/footer.php'; ?>