<?php
// key

$appName = 'WarungKu';


$baseUrl = 'http://localhost/devity-apps/';

$roleLabels = [
  1 => 'User',
  2 => 'Admin',
  3 => 'Super Admin',
];





define('BASE_URL', isset($baseUrl) ? $baseUrl : 'http://example.com/');
define('APP_NAME', isset($appName) ? $appName : 'Devity');
